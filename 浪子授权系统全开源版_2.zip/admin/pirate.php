<?php
include("../includes/common.php");
$title='盗版站点';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>